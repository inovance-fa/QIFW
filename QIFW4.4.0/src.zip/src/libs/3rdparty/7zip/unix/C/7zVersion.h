#define MY_VER_MAJOR 9
#define MY_VER_MINOR 38
#define MY_VER_BUILD 00
#define MY_VERSION "9.38 beta"
// #define MY_7ZIP_VERSION "9.38"
#define MY_DATE "2015-01-03"
#undef MY_COPYRIGHT
#undef MY_VERSION_COPYRIGHT_DATE
#define MY_COPYRIGHT ": Igor Pavlov : Public domain"
#define MY_VERSION_COPYRIGHT_DATE MY_VERSION " " MY_COPYRIGHT " : " MY_DATE

#define P7ZIP_VERSION "9.38.1"

